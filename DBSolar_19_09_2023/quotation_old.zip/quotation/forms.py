from django import forms
from .models import Quotation, STRUCTURE_CHOICES, INV_PHASE_CHOICES, SolarPanelCompany, InverterCompany, Representative
from .models import Quotation, OtherItem, SolarPanelCompany, InverterCompany, STRUCTURE_CHOICES, INV_PHASE_CHOICES
#
PANEL_TYPE_CHOICES = [
    ('Bifacial DCR', 'Bifacial DCR'),
    ('Bifacial NDCR', 'Bifacial NDCR'),
    ('TOPCon DCR', 'TOPCon DCR'),
    ('TOPCon NDCR', 'TOPCon NDCR'),
    ('Mono PERC DCR', 'Mono PERC DCR'),
    ('Mono PERC NDCR', 'Mono PERC NDCR'),
    ('Poly DCR', 'Poly DCR'),
    ('Poly NDCR', 'Poly NDCR'),
    ('HJT DCR', 'HJT DCR'),
    ('HJT NDCR', 'HJT NDCR'),
]

PRICING_MODE_CHOICES = [
    ('net', 'Net Amount'),
    ('final', 'Final Amount'),
]

# OTHER_CHOICES = [
#         ('Walkway', 'Walkway'),
#         ('Staircase', 'Staircase'),
#         ('Plumbing', 'Plumbing'),
#         ('Safety Railing', 'Safety Railing'),
#         ('GI Tray', 'GI Tray'),
#     ]
#
# class QuotationForm(forms.ModelForm):
#     plant_capacity_kw = forms.ChoiceField(choices=[('3.3','3.3 kW'), ('5','5 kW'), ('10','10 kW')])
#     panel_type = forms.ChoiceField(choices=PANEL_TYPE_CHOICES)
#     inv_phase = forms.ChoiceField(choices=INV_PHASE_CHOICES)
#     structure_type = forms.ChoiceField(choices=STRUCTURE_CHOICES)
#     pricing_mode = forms.ChoiceField(choices=PRICING_MODE_CHOICES, required=True)
#     net_amount_input = forms.DecimalField(required=False, max_digits=14, decimal_places=2)
#     final_amount_input = forms.DecimalField(required=False, max_digits=14, decimal_places=2)
#
#     panel_manufacturing_warranty = forms.CharField(required=False)
#     panel_performance_warranty = forms.CharField(required=False)
#
#     inverter_warranty = forms.CharField(required=False)
#     structure_warranty = forms.CharField(required=False)
#
#     # other fields unchanged...
#     other_items = forms.ModelMultipleChoiceField(
#         queryset=OtherItem.objects.all().order_by('name'),
#         required=False,
#         widget=forms.CheckboxSelectMultiple
#     )
#
#     panel_companies = forms.ModelMultipleChoiceField(
#         queryset=SolarPanelCompany.objects.all(),
#         required=False,
#         widget=forms.CheckboxSelectMultiple
#     )
#
#     inverter_companies = forms.ModelMultipleChoiceField(
#         queryset=InverterCompany.objects.all(),
#         required=False,
#         widget=forms.CheckboxSelectMultiple
#     )
#
#     class Meta:
#         model = Quotation
#         # fields = [
#         #     'consumer_name', 'consumer_address1', 'consumer_address2', 'consumer_no', 'consumer_mobile',
#         #     'date', 'plant_capacity_kw', 'employee_name',
#         #     'panel_type', 'panel_capacity_watt',
#         #     'inv_phase', 'inv_capacity_kw',
#         #     'panel_companies',  # <-- ADD
#         #     'inverter_companies',  # <-- ADD
#         #     'structure_type', 'structure_back_height_ft', 'structure_front_height_ft',
#         #     'special_discount', 'gst_5_percent', 'gst_18_percent'
#         # ]
#         fields = [
#             'consumer_name', 'consumer_address1', 'consumer_address2',
#             'consumer_no', 'consumer_mobile', 'date', 'plant_capacity_kw', 'employee_name',
#
#             'panel_type', 'panel_capacity_watt',
#             'panel_manufacturing_warranty', 'panel_performance_warranty',
#
#             'inv_phase', 'inv_capacity_kw', 'inverter_warranty',
#
#             'panel_companies', 'inverter_companies',
#
#             'structure_type', 'structure_back_height_ft', 'structure_front_height_ft',
#
#             # 'walkway', 'staircase', 'plumbing', 'safety_railing', 'gi_tray',
#
#             'special_discount', 'gst_5_percent', 'gst_18_percent',
#             'other_items', 'structure_warranty',
#         ]
#         widgets = {
#             'date': forms.DateInput(attrs={'type': 'date'}),
#         }
class QuotationForm(forms.ModelForm):
    plant_capacity_kw = forms.ChoiceField(choices=[('3.3','3.3 kW'), ('5','5 kW'), ('10','10 kW')])
    panel_type = forms.ChoiceField(choices=PANEL_TYPE_CHOICES)
    inv_phase = forms.ChoiceField(choices=INV_PHASE_CHOICES)
    structure_type = forms.ChoiceField(choices=STRUCTURE_CHOICES)
    pricing_mode = forms.ChoiceField(choices=PRICING_MODE_CHOICES, required=True)
    net_amount_input = forms.DecimalField(required=False, max_digits=14, decimal_places=2)
    final_amount_input = forms.DecimalField(required=False, max_digits=14, decimal_places=2)

    panel_manufacturing_warranty = forms.CharField(required=False)
    panel_performance_warranty = forms.CharField(required=False)

    panel_qty = forms.IntegerField(required=False)
    inverter_qty = forms.IntegerField(required=False)

    inverter_warranty = forms.CharField(required=False)
    structure_warranty = forms.CharField(required=False)

    # form.py (inside QuotationForm)

    representatives = forms.ModelMultipleChoiceField(
        queryset=Representative.objects.all().order_by('name'),
        required=False,
        widget=forms.CheckboxSelectMultiple
    )

    other_items = forms.ModelMultipleChoiceField(
        queryset=OtherItem.objects.all().order_by('name'),
        required=False,
        widget=forms.CheckboxSelectMultiple
    )

    panel_companies = forms.ModelMultipleChoiceField(
        queryset=SolarPanelCompany.objects.all(),
        required=False,
        widget=forms.CheckboxSelectMultiple
    )

    inverter_companies = forms.ModelMultipleChoiceField(
        queryset=InverterCompany.objects.all(),
        required=False,
        widget=forms.CheckboxSelectMultiple
    )

    class Meta:
        model = Quotation
        fields = [
            'consumer_name', 'consumer_address1', 'consumer_address2', 'employee_name', 'panel_qty', 'inverter_qty',
            'consumer_no', 'consumer_mobile', 'date', 'plant_capacity_kw',

            'panel_type', 'panel_capacity_watt',
            'panel_manufacturing_warranty', 'panel_performance_warranty',
            'representatives',  # <-- add here
            'inv_phase', 'inv_capacity_kw', 'inverter_warranty',

            'panel_companies', 'inverter_companies',

            'structure_type', 'structure_back_height_ft', 'structure_front_height_ft',

            'special_discount', 'gst_5_percent', 'gst_18_percent',
            'other_items', 'structure_warranty',
        ]
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
        }

    # ✅ Add this method
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for field_name, field in self.fields.items():
            # Skip checkbox groups
            if isinstance(field.widget, forms.CheckboxSelectMultiple):
                continue

            # Apply Bootstrap form-control
            existing_classes = field.widget.attrs.get('class', '')
            field.widget.attrs['class'] = f'{existing_classes} form-control'.strip()


#
# class QuotationItemForm(forms.ModelForm):
#     product = forms.ModelChoiceField(queryset=QuotationProduct.objects.all(), widget=forms.Select())
#     class Meta:
#         model = QuotationItem
#         fields = ['product', 'description', 'quantity', 'unit_price']
#         widgets = {
#             'description': forms.TextInput(attrs={'placeholder': 'Short description (optional)'}),
#             'quantity': forms.NumberInput(attrs={'step': '0.01'}),
#             'unit_price': forms.NumberInput(attrs={'step': '0.01'}),
#         }




class SolarPanelCompanyForm(forms.ModelForm):
    class Meta:
        model = SolarPanelCompany
        fields = ['name']


class InverterCompanyForm(forms.ModelForm):
    class Meta:
        model = InverterCompany
        fields = ['name']
