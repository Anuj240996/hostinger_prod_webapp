from decimal import Decimal, ROUND_HALF_UP
from django.db import models
from django.utils import timezone
from django.db.models import Max

def money(v):
    if not isinstance(v, Decimal):
        v = Decimal(v)
    return v.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)


STRUCTURE_CHOICES = [
    ('GI Structure', 'GI Structure'),
    ('Tin Shade', 'Tin Shade'),
    ('MS Structure', 'MS Structure'),
]

INV_PHASE_CHOICES = [
    ('Single Phase', 'Single Phase'),
    ('Three Phase', 'Three Phase'),
]


class SolarPanelCompany(models.Model):
    name = models.CharField(max_length=100, unique=True)
    def __str__(self):
        return self.name


class InverterCompany(models.Model):
    name = models.CharField(max_length=100, unique=True)
    def __str__(self):
        return self.name

#
# class QuotationProduct(models.Model):
#     name = models.CharField(max_length=255)
#     unit = models.CharField(max_length=50, blank=True)
#     unit_price = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
#     make = models.CharField(max_length=255, blank=True)
#     warranty = models.CharField(max_length=255, blank=True)
#     def __str__(self):
#         return self.name

class OtherItem(models.Model):
    name = models.CharField(max_length=200, unique=True)

    def __str__(self):
        return self.name





class Representative(models.Model):
    name = models.CharField(max_length=255)
    contact = models.CharField(max_length=50, blank=True)

    class Meta:
        unique_together = ('name', 'contact')  # optional but useful

    def __str__(self):
        if self.contact:
            return f"{self.name} — {self.contact}"
        return self.name



class Quotation(models.Model):
    consumer_name = models.CharField(max_length=255)
    consumer_address1 = models.CharField(max_length=255, blank=True)
    consumer_address2 = models.CharField(max_length=255, blank=True)
    consumer_no = models.CharField(max_length=50, blank=True)
    consumer_mobile = models.CharField(max_length=20, blank=True)

    quotation_no = models.CharField(max_length=20, unique=True, blank=True)
    date = models.DateTimeField(default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)

    plant_capacity_kw = models.DecimalField(max_digits=6, decimal_places=2, default=Decimal('3.30'))
    employee_name = models.CharField(max_length=255, blank=True)

    panel_companies = models.ManyToManyField(SolarPanelCompany, blank=True)
    inverter_companies = models.ManyToManyField(InverterCompany, blank=True)

    panel_qty = models.IntegerField(default=0)
    inverter_qty = models.IntegerField(default=0)
    panel_type = models.CharField(max_length=100, blank=True)
    panel_capacity_watt = models.CharField(max_length=100, blank=True)
    inv_phase = models.CharField(max_length=13, choices=INV_PHASE_CHOICES, default='1 Phase')
    inv_capacity_kw = models.DecimalField(max_digits=6, decimal_places=2, default=Decimal('3.30'))
    panel_company_names = models.TextField(blank=True)  # NEW
    inverter_company_names = models.TextField(blank=True)  # NEW
    # PANEL WARRANTY
    panel_manufacturing_warranty = models.CharField(max_length=50, blank=True)
    panel_performance_warranty = models.CharField(max_length=50, blank=True)

    # INVERTER WARRANTY
    inverter_warranty = models.CharField(max_length=50, blank=True)

    # other_details = JSONField(default=dict, blank=True)
    other_details = models.TextField(blank=True)

    structure_type = models.CharField(max_length=50, choices=STRUCTURE_CHOICES, default='GI Structure')
    structure_back_height_ft = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    structure_front_height_ft = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    structure_warranty = models.CharField(max_length=100, blank=True, null=True)

    special_discount = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    gst_5_percent = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('5.00'))
    gst_18_percent = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('18.00'))
    gst_5_amount = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    gst_18_amount = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))

    net_amount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0.00'))
    final_amount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0.00'))
    # In Quotation model add:
    representatives = models.ManyToManyField(Representative, blank=True)
    representative_names = models.TextField(blank=True)  # a cached textual list used for the PDF (optional)

    def __str__(self):
        return f"Quotation {self.quotation_no} - {self.consumer_name}"

    def save(self, *args, **kwargs):
        if not self.quotation_no:
            last = Quotation.objects.aggregate(maxno=Max('quotation_no'))['maxno']
            newno = int(last) + 1 if last and last.isdigit() else 1000
            self.quotation_no = str(newno)
        super().save(*args, **kwargs)

    # def calculate_from_net(self):
    #     gst5p = self.gst_5_percent / 100
    #     gst18p = self.gst_18_percent / 100
    #     base = self.net_amount
    #     gst5 = base * Decimal('0.70') * gst5p
    #     gst18 = base * Decimal('0.30') * gst18p
    #     total = base + gst5 + gst18 - self.special_discount
    #     self.gst_5_amount = money(gst5)
    #     self.gst_18_amount = money(gst18)
    #     self.final_amount = money(total)
    #     self.save()
    #
    # def calculate_from_final(self):
    #     gst5p = self.gst_5_percent / 100
    #     gst18p = self.gst_18_percent / 100
    #     gst_factor = (Decimal('0.70') * gst5p) + (Decimal('0.30') * gst18p)
    #     base = self.final_amount / (Decimal('1.00') + gst_factor)
    #     gst5 = base * Decimal('0.70') * gst5p
    #     gst18 = base * Decimal('0.30') * gst18p
    #     self.gst_5_amount = money(gst5)
    #     self.gst_18_amount = money(gst18)
    #     self.net_amount = money(base)
    #     self.save()

    def calculate_from_net(self):
        """
        Correct GST calculation:
        5% GST on 70% of net
        18% GST on 30% of net
        final = net + gst5 + gst18 - discount
        """

        net = Decimal(self.net_amount or 0)
        discount = Decimal(self.special_discount or 0)

        gst5 = (net * Decimal('0.70')) * Decimal('0.05')
        gst18 = (net * Decimal('0.30')) * Decimal('0.18')

        self.gst_5_amount = money(gst5)
        self.gst_18_amount = money(gst18)

        self.gst_5_percent = self.gst_5_amount
        self.gst_18_percent = self.gst_18_amount

        self.final_amount = money(net + gst5 + gst18 - discount)


    def calculate_from_final(self):
        """
        Reverse GST calculation:
        Determine base amount from final = base * (1 + GST%)
        """

        final_amt = Decimal(self.final_amount or 0)
        discount = Decimal(self.special_discount or 0)

        # combined effective GST = 3.5% + 5.4% = 8.9%
        gst_factor = (Decimal('0.70') * Decimal('0.05')) + (Decimal('0.30') * Decimal('0.18'))

        base = (final_amt + discount) / (1 + gst_factor)

        gst5 = (base * Decimal('0.70')) * Decimal('0.05')
        gst18 = (base * Decimal('0.30')) * Decimal('0.18')

        self.net_amount = money(base)

        self.gst_5_amount = money(gst5)
        self.gst_18_amount = money(gst18)

        self.gst_5_percent = self.gst_5_amount
        self.gst_18_percent = self.gst_18_amount

        self.final_amount = money(base + gst5 + gst18 - discount)


# models.py (additions)


# class QuotationItem(models.Model):
#     quotation = models.ForeignKey(Quotation, on_delete=models.CASCADE, related_name='items')
#     product = models.ForeignKey(QuotationProduct, on_delete=models.PROTECT)
#     description = models.TextField(blank=True)
#     quantity = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('1.00'))
#     unit_price = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
#
#     def line_total(self):
#         return money(self.quantity * self.unit_price)
#
#     def __str__(self):
#         return f"{self.product.name} x {self.quantity}"
