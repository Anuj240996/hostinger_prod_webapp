from django import template

register = template.Library()

@register.filter
def clean_decimal(value):
    """
    Show integer without decimals.
    Show decimal only when needed.
    """
    try:
        value = float(value)
    except:
        return value

    if value.is_integer():
        return str(int(value))  # remove .0
    return str(value)          # keep decimal
